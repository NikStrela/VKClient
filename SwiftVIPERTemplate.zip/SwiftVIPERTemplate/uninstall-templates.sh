#!/usr/bin/env sh

TEMPLATES_DIR="$HOME/Library/Developer/Xcode/Templates"
FILE_TEMPLATES_DIR="$TEMPLATES_DIR/File Templates"
VIPER_TEMPLATES_DIR="$FILE_TEMPLATES_DIR/Swift VIPER"
echo "Removing $VIPER_TEMPLATES_DIR"
rm -rf "$VIPER_TEMPLATES_DIR"
echo "Finished"
