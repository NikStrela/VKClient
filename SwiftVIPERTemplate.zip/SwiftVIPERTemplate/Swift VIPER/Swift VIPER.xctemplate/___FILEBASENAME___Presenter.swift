//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation

protocol ___VARIABLE_moduleName___ViewOutput: ViewOutput {
}

final class ___VARIABLE_moduleName___Presenter {
    
    // MARK: - Public Properties
    
    weak var view: ___VARIABLE_moduleName___ViewInput?
    var interactor: ___VARIABLE_moduleName___InteractorInput?
    var router: ___VARIABLE_moduleName___RouterInput?
    
    // MARK: - Init
    
    init() {
    }
}

// MARK: - ___VARIABLE_moduleName___ViewOutput

extension ___VARIABLE_moduleName___Presenter: ___VARIABLE_moduleName___ViewOutput {
}

// MARK: - ___VARIABLE_moduleName___InteractorOutput

extension ___VARIABLE_moduleName___Presenter: ___VARIABLE_moduleName___InteractorOutput {
}
