//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  /
//

import Foundation


protocol ___VARIABLE_moduleName___InteractorInput {
}

protocol ___VARIABLE_moduleName___InteractorOutput: AnyObject {
}

final class ___VARIABLE_moduleName___Interactor {
    
    // MARK: - Public Properties
    
    weak var presenter: ___VARIABLE_moduleName___InteractorOutput?
    
    // MARK: Init
    
    init() {
    }
}

// MARK: - ___VARIABLE_moduleName___InteractorInput

extension ___VARIABLE_moduleName___Interactor: ___VARIABLE_moduleName___InteractorInput {
}
