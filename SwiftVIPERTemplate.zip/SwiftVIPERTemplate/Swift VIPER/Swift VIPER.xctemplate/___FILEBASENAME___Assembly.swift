//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  /
//

import UIKit

final class ___VARIABLE_moduleName___Assembly: Assembly {
    
    static func assembleModule(with model: TransitionModel) -> UIViewController {
        guard let model = model as? Model
            else { fatalError() }
        
        let view = ___VARIABLE_moduleName___ViewController()
        let router = ___VARIABLE_moduleName___Router()
        let presenter = ___VARIABLE_moduleName___Presenter()
        let interactor = ___VARIABLE_moduleName___Interactor()
        
        view.presenter = presenter
        
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        
        interactor.presenter = presenter
        
        router.view = view
        
        return view
    }
}

// MARK: - Transition model

extension ___VARIABLE_moduleName___Assembly {
    
    struct Model: TransitionModel {
    }
}
