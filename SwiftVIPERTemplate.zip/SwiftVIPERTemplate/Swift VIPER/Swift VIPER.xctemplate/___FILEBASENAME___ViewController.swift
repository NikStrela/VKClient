//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit

protocol ___VARIABLE_moduleName___ViewInput: AnyObject {
}

class ___VARIABLE_moduleName___ViewController: UIViewController {
    
    // MARK: - Public Properties
    
    var presenter: ___VARIABLE_moduleName___ViewOutput?

     // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

// MARK: - ___VARIABLE_moduleName___ViewInput

extension ___VARIABLE_moduleName___ViewController: ___VARIABLE_moduleName___ViewInput {
}
