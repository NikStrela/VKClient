//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation
import UIKit

protocol ___VARIABLE_moduleName___RouterInput {
}

final class ___VARIABLE_moduleName___Router: NSObject {
    
    // MARK: - Public Properties
    
    weak var view: ModuleTransitionHandler?
}

// MARK: - ___VARIABLE_moduleName___RouterInput

extension ___VARIABLE_moduleName___Router: ___VARIABLE_moduleName___RouterInput {
}
